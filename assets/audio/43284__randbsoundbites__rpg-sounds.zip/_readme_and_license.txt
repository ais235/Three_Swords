Pack downloaded from Freesound
----------------------------------------

"RPG Sounds"

This Pack of sounds contains sounds by the following user:
 - randbsoundbites ( https://freesound.org/people/randbsoundbites/ )

You can find this pack online at: https://freesound.org/people/randbsoundbites/packs/43284/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 844290__randbsoundbites__popping-open-a-potion-or-elixir-for-rpg-game.wav.wav
    * url: https://freesound.org/s/844290/
    * license: Creative Commons 0
  * 844286__randbsoundbites__goblin-taking-damage-in-combat.wav.wav
    * url: https://freesound.org/s/844286/
    * license: Creative Commons 0
  * 843575__randbsoundbites__wounded-character.wav.wav
    * url: https://freesound.org/s/843575/
    * license: Creative Commons 0
  * 843573__randbsoundbites__dying-breath.wav.wav
    * url: https://freesound.org/s/843573/
    * license: Creative Commons 0
  * 843572__randbsoundbites__dying-breath-3.wav.wav
    * url: https://freesound.org/s/843572/
    * license: Creative Commons 0
  * 843571__randbsoundbites__dying-breath-2.wav.wav
    * url: https://freesound.org/s/843571/
    * license: Creative Commons 0
  * 829806__randbsoundbites__adding-an-item-to-inventory-2.wav.wav
    * url: https://freesound.org/s/829806/
    * license: Creative Commons 0
  * 808094__randbsoundbites__various-injury-sounds-for-game-character.wav.wav
    * url: https://freesound.org/s/808094/
    * license: Creative Commons 0
  * 808093__randbsoundbites__character-death.wav.wav
    * url: https://freesound.org/s/808093/
    * license: Creative Commons 0
  * 808092__randbsoundbites__character-death-2.wav.wav
    * url: https://freesound.org/s/808092/
    * license: Creative Commons 0
  * 804664__randbsoundbites__opening-a-magic-potion.wav.wav
    * url: https://freesound.org/s/804664/
    * license: Creative Commons 0
  * 804663__randbsoundbites__opening-magic-potion-3.wav.wav
    * url: https://freesound.org/s/804663/
    * license: Creative Commons 0
  * 804662__randbsoundbites__opening-a-magic-potion.wav.wav
    * url: https://freesound.org/s/804662/
    * license: Creative Commons 0
  * 800363__randbsoundbites__enemy-death-sounds-x2.wav.wav
    * url: https://freesound.org/s/800363/
    * license: Creative Commons 0
  * 800362__randbsoundbites__enemy-death-cries-x2.wav.wav
    * url: https://freesound.org/s/800362/
    * license: Creative Commons 0
  * 800361__randbsoundbites__orc-taking-damage.wav.wav
    * url: https://freesound.org/s/800361/
    * license: Creative Commons 0
  * 800360__randbsoundbites__orc-dying-sounds.wav.wav
    * url: https://freesound.org/s/800360/
    * license: Creative Commons 0
  * 798649__randbsoundbites__the-last-gasp-before-death.wav.wav
    * url: https://freesound.org/s/798649/
    * license: Creative Commons 0
  * 797849__randbsoundbites__injured.wav.wav
    * url: https://freesound.org/s/797849/
    * license: Creative Commons 0
  * 795440__randbsoundbites__grunting.wav.wav
    * url: https://freesound.org/s/795440/
    * license: Creative Commons 0
  * 794532__randbsoundbites__opening-a-magic-potion-4-the-original.wav.wav
    * url: https://freesound.org/s/794532/
    * license: Creative Commons 0
  * 791150__randbsoundbites__dropping-an-item-from-inventory.wav.wav
    * url: https://freesound.org/s/791150/
    * license: Creative Commons 0


